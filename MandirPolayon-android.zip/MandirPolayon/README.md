# মন্দির পলায়ন: অ্যান্ড্রয়েড অ্যাপ

পুরো গেম, 3D ইঞ্জিনসহ, `app/src/main/assets/index.html` ফাইলের ভেতরে রাখা আছে।
অ্যাপ চালাতে ইন্টারনেট লাগে না, আর অ্যাপ কোনো অনুমতিও চায় না।

## APK বানানোর তিনটা উপায়

### ১. GitHub দিয়ে (কম্পিউটার ছাড়া, ফোন থেকেও করা যায়)
1. github.com-এ একটা ফ্রি অ্যাকাউন্ট খুলুন।
2. নতুন একটা রিপোজিটরি বানান, যেমন `mandir-polayon`।
3. এই ফোল্ডারের সব ফাইল সেখানে আপলোড করুন। `.github` ফোল্ডারটাও যেন যায়।
4. আপলোড হলে GitHub নিজে থেকেই APK বানানো শুরু করবে। **Actions** ট্যাবে গিয়ে
   "Build APK" কাজটা খুলুন। ৩-৫ মিনিট পর সবুজ টিক দেখাবে।
5. নিচের **Artifacts** অংশ থেকে `mandir-polayon-apk` নামিয়ে আনজিপ করুন।
   ভেতরে `app-debug.apk` পাবেন।

### ২. Android Studio দিয়ে (কম্পিউটারে)
1. Android Studio খুলে **Open** দিয়ে এই ফোল্ডারটা বেছে নিন।
2. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। প্রথমবার ইন্টারনেট লাগবে।
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)** চাপুন।
4. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।

### ৩. কমান্ড লাইন দিয়ে (Android SDK আর JDK 17 থাকলে)
```
./gradlew assembleDebug
```

## ফোনে ইনস্টল করা
1. `app-debug.apk` ফোনে নিন।
2. ফাইলটায় ট্যাপ করুন। ফোন "অজানা উৎস থেকে ইনস্টল" করার অনুমতি চাইলে ওই অ্যাপের জন্য অনুমতি দিন।
3. Install চাপুন। Play Protect সতর্ক করলে "Install anyway" চাপুন। APK-টা আপনার নিজের বানানো, Play Store থেকে আসেনি বলেই এই সতর্কতা দেখায়।

## Play Store-এ দিতে চাইলে
Play Store-এ debug APK নেয় না। তখন Android Studio-তে
**Build → Generate Signed App Bundle** দিয়ে নিজের key দিয়ে সাইন করা `.aab` ফাইল বানাতে হবে।
key ফাইল আর তার পাসওয়ার্ড যত্ন করে রাখুন। এগুলো হারালে পরে অ্যাপ আপডেট করা যাবে না।

## ফাইলগুলো কী
| ফাইল | কাজ |
|---|---|
| `app/src/main/assets/index.html` | পুরো গেম (three.js r128 সহ, MIT লাইসেন্স) |
| `app/src/main/java/.../MainActivity.java` | ফুল-স্ক্রিন WebView-এ গেমটা চালায় |
| `.github/workflows/build-apk.yml` | GitHub-এ নিজে থেকে APK বানায় |
| `store-icon-512.png` | Play Store-এর জন্য ৫১২×৫১২ আইকন |
